
python3 grayhatwarfare/scripts/python/download_urls.py -q grayhatwarfare/queries/pi-short.csv -o ghw_metadata.json -v


#python3 utils/download_files_from_ghw_metadata.py -m ghw_metadata.json -d tmp_folder -v


#grep -Er '([[:alnum:]_.-]+)@(x.com|y.com)' tmp_folder/ | cut -d ":" -f 1 | uniq -c | sort -u | sed 's/^ *//g' | sed -r 's/\s+/,/'

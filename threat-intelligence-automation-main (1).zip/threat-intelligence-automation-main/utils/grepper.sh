#!/bin/bash

rm -rf output.txt

for a in $(cat scope.txt); do egrep -nHrai $a tmp_folder/csv_files/; done >> output.txt
for a in $(cat scope.txt); do egrep -nHrai $a tmp_folder/text_files/; done >> output.txt
for a in $(cat scope.txt); do egrep -nHrai $a tmp_folder/undefined_files/; done >> output.txt

for a in $(cat scope.txt); do ugrep -nHri $a tmp_folder/xls_files/; done >> output.txt
for a in $(cat scope.txt); do ugrep -nHri $a tmp_folder/xlsx_files/; done >> output.txt
for a in $(cat scope.txt); do ugrep -nHri $a tmp_folder/odt_files/; done >>output.txt
for a in $(cat scope.txt); do ugrep -nHri $a tmp_folder/undefined_files/; done >> output.txt

for a in $(cat scope.txt); do pdfgrep -nHri $a tmp_folder/pdf_files/; done >> output.txt


b=$(cat output.txt | cut -d "/" -f 3 | cut -d ":" -f 1 | rev | cut -d "_" -f 2- | rev | sort -u); for a in $b; do cat ghw_metadata.json | grep $a;done

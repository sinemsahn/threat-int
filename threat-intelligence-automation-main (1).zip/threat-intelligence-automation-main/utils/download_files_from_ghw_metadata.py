import argparse
import urllib.request
import threading
import random
import shutil
import logging
import sys
import magic
import os
import json
import fcntl
import ssl
import zlib

from datetime import datetime
from hurry.filesize import size as hr_size

filetypes = {
    "PDF": "pdf_files",
    "ASCII Text": "text_files",
    "CSV text": "csv_files",
    "Composite Document" : "xls_files",
    "Microsoft Excel" : "xlsx_files",
    "OpenDocument": "odt_files"
}

TEMP_DIR = "tmp/"

UNDEFINED_FILETYPES_DIR = "undefined_files"
NOTALLOWED_FILETYPES = ["HTML document"]
USER_AGENT_STRING = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) "\
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36"
CHUNK_SIZE = 16*1024


def compute_crc(filename):
    prev = 0
    for line in open(filename, "rb"):
        prev = zlib.crc32(line, prev)
    return "%X" % (prev & 0xFFFFFFFF)


def filetype_allowed(filetype):
    for i in NOTALLOWED_FILETYPES:
        if i.lower() in filetype.lower():
            return False
    return True


def get_filetype_dir(filetype):
    for k, v in filetypes.items():
        if k.lower() in filetype.lower():
            return v
    return UNDEFINED_FILETYPES_DIR


def download_file(url, ghw_date, out_dir, metadata_file):
    # disable ssl certificate check
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    # URL preprocessing: replace space with %20
    url = url.strip().replace(" ", "%20")

    # get file name from the url and append random
    # number to avoid collissions
    outfilename = url.split("/")[-1] + "_" + str(
        random.randint(0, sys.maxsize)
    )
    tmp_outfile = TEMP_DIR + outfilename
    try:
        response = urllib.request.urlopen(
            urllib.request.Request(
                url,
                headers={
                    "User-Agent": USER_AGENT_STRING
                }
            ),
            context=ctx
        )

        # save the file in tmp folder
        with open(tmp_outfile, "wb") as f:
            size = 0
            while True:
                chunk = response.read(CHUNK_SIZE)
                if not chunk:
                    break
                f.write(chunk)
                size += len(chunk)

        # only save the file if its size is greater than 0
        if size > 0:
            crc = compute_crc(tmp_outfile)
            todays_date = datetime.today().strftime("%H:%M/%m/%d/%Y")
            filetype = magic.from_file(tmp_outfile)

            # dont move the file, if filetype is not allowed: e.g. html page.
            # if we dont move it, it will be deleted once we delete tmp folder
            if filetype_allowed(filetype):
                filetype_dir = get_filetype_dir(filetype)
                outfile = out_dir + "/" + filetype_dir + "/" + outfilename
                os.rename(tmp_outfile, outfile)

                with open(metadata_file, "a") as f:

                    # locking the file to avoid race conditions
                    fcntl.flock(f, fcntl.LOCK_EX)
                    f.write(",".join([
                        outfile,
                        url,
                        todays_date,
                        str(ghw_date),
                        crc,
                        str(size),
                        filetype
                    ]) + "\n")
                    fcntl.flock(f, fcntl.LOCK_UN)

    except (urllib.error.URLError, urllib.error.HTTPError) as err:
        logging.error(
            "could not download %s due to %s", url, err
        )

    except MemoryError:
        logging.error(
            "could not download %s due to MemoryError", url
        )


def already_downloaded(file, metadata_file):
    if not os.path.isfile(metadata_file):
        return False
    with open(metadata_file, "r") as f:
        for line in f:
            url = line.split(",")[1]
            if url == file["url"]:
                old_ghw_date = int(line.split(",")[3], 10)
                new_ghw_date = file["lastModified"]

                # The file is already downloaded and
                # current ghw date is not changed
                if new_ghw_date <= old_ghw_date:
                    logging.info(
                        "file %s is already downloaded:"
                        " last modified %d", url, file["lastModified"]
                    )
                    return True
                else:
                    break
    return False


def check_total_size(ghw_meta_file, out_dir):
    metadata_file = "metadata.csv"
    with open(ghw_meta_file, "r") as f:
        ghw_metadata_content = f.readlines()

    files = []

    for x in ghw_metadata_content:
        try:
            files.append(json.loads(x))
        except json.decoder.JSONDecodeError:
            logging.error("Could not decode JSON %s", x)

    total_size = 0
    for elem in files:
        total_size += int(elem["size"])

    print(hr_size(total_size))
#    sys.exit(0)


def download_files(ghw_meta_file, out_dir, number_of_threads=4):
    metadata_file = "metadata.csv"
    with open(ghw_meta_file, "r") as f:
        ghw_metadata_content = f.readlines()

    files = []

    for x in ghw_metadata_content:
        try:
            files.append(json.loads(x))
        except json.decoder.JSONDecodeError:
            logging.error("Could not decode JSON %s", x)


    urls = [
        (x["url"], x["lastModified"]) for x in files
        if not already_downloaded(x, metadata_file)
    ]

    chunks = [
        urls[i * number_of_threads:(i + 1) * number_of_threads]
        for i in range(
            (len(urls) + number_of_threads - 1) // number_of_threads
        )
    ]

    for i, chunk in enumerate(chunks):
        threads = []
        for j, url in enumerate(chunk):
            if j % 100:
                logging.info("Chunk %d of %d", i, len(chunks))
            thread = threading.Thread(
                target=download_file, args=(
                    url[0],
                    url[1],
                    out_dir,
                    metadata_file
                )
            )
            thread.start()
            threads.append(thread)
        for thread in threads:
            thread.join()


def parse_args():
    parser = argparse.ArgumentParser(
        description="Find Gray Hat Warfare results for a query"
    )
    parser.add_argument(
        "-m",
        "--metadata-file",
        action="store",
        dest="meta_file",
        required=True,
        help="GHW Metadata file, For example: ghw_metadata.json",
    )
    parser.add_argument(
        "-d",
        "--out-dir",
        action="store",
        dest="out_dir",
        required=True,
        help="Output directory, For example: data",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        dest="verbose",
        help="Show warnings and debug information",
    )
    args = parser.parse_args()
    return args.meta_file, args.out_dir, args.verbose


def init_dirs(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for _, v in filetypes.items():
        os.makedirs(out_dir + "/" + v, exist_ok=True)
    os.makedirs(out_dir + "/" + UNDEFINED_FILETYPES_DIR, exist_ok=True)
    os.makedirs(TEMP_DIR, exist_ok=True)


def main(meta_file, out_dir):
    check_total_size(meta_file, out_dir)
    init_dirs(out_dir)
    download_files(meta_file, out_dir)
    shutil.rmtree(TEMP_DIR)


def init_logger():
    logging.basicConfig()
    logging.root.setLevel(logging.NOTSET)


if __name__ == "__main__":
    init_logger()
    _meta_file, _out_dir, _verbose = parse_args()

    if not _verbose:
        logging.disable(logging.CRITICAL)
    else:
        logging.disable(logging.DEBUG)

    main(_meta_file, _out_dir)

sudo apt update
sudo apt install libmagic1
pip3 install -r requirements.txt

#Quick hack for now as git doesnt 
#let me upload empty directories.

mkdir output
mkdir output/pdf_files
mkdir output/undefined_files
mkdir output/text_files


# Usage: ./make-company-queries.sh "company name"
cat google-company.csv | sed 's/"company"/'\""$1"\"'/g'

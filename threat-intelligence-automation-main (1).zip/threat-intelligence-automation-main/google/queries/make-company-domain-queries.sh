# Usage: ./make-company-domain-queries.sh "company name" "domainname.com"
cat google-company-domain.csv | sed 's/"company"/'\""$1"\"'/g' | sed 's/"domain"/'\""$2"\"'/g'

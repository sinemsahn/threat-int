# Usage: ./make-domain-queries.sh "company name"
cat google-domain.csv | sed 's/"domain"/'\""$1"\"'/g'

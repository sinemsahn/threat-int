import argparse
from ratelimit import limits, sleep_and_retry
import requests
import json
import os
from tqdm import tqdm
import logging
import pathlib


GOOGLE_DORK_CSVS_LIST = [
    pathlib.Path(__file__).parent.resolve().as_posix() + "/../queries/google-company-domain.csv",
]

API_BASE_PATH = "https://modules01.s55m5xvqi9my6phh3pebassvn2rsxbnk.com"
GOOGLE_MODULE_ENDPOINT = "/v1/googlesearch"
GOOGLE_MODULE_URL = API_BASE_PATH + GOOGLE_MODULE_ENDPOINT
REQUIRED_HEADERS = ["Content-Type", "Content-Length", "Host", "api-key"]
API_KEY = "5AqgASGH6VorKKhnwqjY6NqkWJFdKFhPDqAHmfCJF7DjtKXcg29tQG4WronnytUi "
EXTENSION_LIST = ["pdf", "txt"]


@sleep_and_retry
@limits(calls=1, period=1)
def get_google_results(query):
    s = requests.Session()
    data = json.dumps(query)
    data = data.replace('\\"', "'")
    request = requests.Request(
        "POST", GOOGLE_MODULE_URL, data=data, headers={"api-key": API_KEY}
    )
    prepared_request = request.prepare()
    for header in prepared_request.headers.keys():
        if header not in REQUIRED_HEADERS:
            del prepared_request.headers[header]

    prepared_request.headers["Host"] = "modules01.s55m5xvqi9my6phh3pebassvn2rsxbnk.com"
    prepared_request.headers["Content-Type"] = "application/json"

    response = s.send(prepared_request)
    if response.status_code != 200:
        logging.error(
            "API Response Code: {}, Reason: {}".format(
                response.status_code, response.reason
            )
        )
        return None

    if len(response.json()["data"]) == 0:
        logging.warning(
            "Response Data length was 0. url: %s, headers: %s, body: %s",
            response.request.url,
            response.request.headers,
            response.request.body,
        )
    return response.json()


def process_results(results, urls_file):
    with open(urls_file, "a") as f:
        for result in results["data"]:
            f.write(result["link"] + "\n")


def run_queries(dorks, urls_file):
    base_query = {"type": "query", "value": None}
    for dork in tqdm(dorks, leave=False):
        query = base_query
        query["value"] = dork
        results = get_google_results(query)
        if results is not None:
            process_results(results, urls_file)


def init_extensions(extension_list):
    if len(extension_list) == 0:
        return ""
    extensions = ""
    for extension in extension_list:
        extensions = extensions + "filetype: " + extension + " "
    return extensions


def init_dorks(company_name, domain_name, csv_list):
    dorks = []
    extensions = init_extensions(EXTENSION_LIST)
    for csv_path in csv_list:
        first_line_read = False
        with open(csv_path, "r") as f:
            for line in f:
                if first_line_read:
                    dorks.append(
                        extensions
                        + line.strip()
                        .split(",")[0]
                        .replace("company", company_name)
                        .replace("domain", domain_name)
                    )
                else:
                    first_line_read = True
    return dorks


def parse_args():
    parser = argparse.ArgumentParser(
        description="Find Google Dork search results for a query"
    )
    parser.add_argument(
        "-c",
        "--company-name",
        action="store",
        dest="company_name",
        required=True,
        help="Company Name, For example: Google",
    )
    parser.add_argument(
        "-d",
        "--domain-name",
        action="store",
        dest="domain_name",
        required=True,
        help="Domain Name, For example: google (without com)",
    )
    parser.add_argument(
        "-o",
        "--output-file",
        action="store",
        dest="urls_file",
        required=True,
        help="Domain Name, For example: google (without .com)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        dest="verbose",
        help="Show warnings and debug information",
    )
    args = parser.parse_args()
    return args.company_name, args.domain_name, args.urls_file, args.verbose


def main(company_name, domain_name, urls_file):
    dorks = init_dorks(company_name, domain_name, GOOGLE_DORK_CSVS_LIST)
    try:
        os.remove(urls_file)
    except FileNotFoundError:
        logging.info("No file to delete: %s does not exist", urls_file)
    run_queries(dorks, urls_file)


def init_logger():
    logging.basicConfig()
    logging.root.setLevel(logging.NOTSET)


if __name__ == "__main__":
    init_logger()
    _company_name, _domain_name, _urls_file, _verbose = parse_args()
    if not _verbose:
        logging.disable(logging.CRITICAL)
    else:
        logging.disable(logging.DEBUG)

    main(_company_name, _domain_name, _urls_file)

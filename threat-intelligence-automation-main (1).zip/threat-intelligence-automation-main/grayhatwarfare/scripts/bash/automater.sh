#!/bin/bash

filename='test.txt'
n=1
while read line; do
    # reading each line
    echo "Line No. $n : $line"
    
    ./fetch.sh "$line" 
    n=$((n+1))
done < $filename



filename="urls_to_download.txt"
sed -i 's/ /%20/' $filename

URLS_TO_DOWNLOAD=$1
cat $filename | parallel -j 8 ./wgetWithMetaData.sh


sed -i "1ifilename,url_source,datetime,hash,filesize_bytes" meta_output.csv
grep -A 1 -B 1 " failed: " log.txt > failedLog.txt

cat failedLog.txt | tr ' ' '\n' | grep 'http' > failedUrls.txt


find ./data -type f -size 0 -delete

##downloaded all of them

for a in data/*
do
    filetype=$(file $a | cut -d "," -f 1 | cut -d ":" -f 2)
    echo "$filetype"

    #move each doc to its own directory
    if [[ "$filetype" == " directory" ]]
    then
        continue
    
    elif [ "$filetype" == " PDF document" ]
    then
        mv "$a" "data/pdf_files/"
        
    
    elif [ "$filetype" == " ASCII text" ]
    then
        mv "$a" "data/text_files/"
    
    else
        mv "$a" "data/undefined_files/"
    fi

done

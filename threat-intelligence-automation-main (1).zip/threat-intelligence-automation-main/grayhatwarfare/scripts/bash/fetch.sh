#!/bin/bash



## Usage: Download all files from a search term from GHW.

        # $1 = search term < User input
        # $2 = API Response
        # $3 = Trimmed URL's

## Check VPN status
#expressvpn status

touch api_output.txt
touch urls_to_download.txt
APIOUTPUT_FILE=api_output.txt    ## File for the immediate output from the api. 
URLS_TO_DOWNLOAD=urls_to_download.txt   ## File for the URLs to be downloaded.
#Input has to be given base64 encoded!
input_keyword=$1
access_token="d1fc915b07cb00ac9681c8f9c22987aa"


#### PULLING URLS TO BE DOWNLOADED FROM THE GREYHATWARFARE API.

## 0..1000 = 1000 PAGES = 1 MILLION RESULTS.
for i in {0..50}; do  ## ONLY MODIFY THIS ONE. 
        j=$(expr $i \* 1000) ## DO NOT MODIFY THE NUMBERS HERE.

        ## Sorting by size also in there.
        extensions="csv,xlsx,xls,pdf,txt"
        query="https://buckets.grayhatwarfare.com/api/v1/files/$input_keyword/$j/1000?access_token=$access_token&order=size&direction=desc&extensions=$extensions"    

        echo $query
        RESULTS_DATA=$(curl --data-urlencode -s $query)
        ## Example URL for full path:
        ## https://buckets.grayhatwarfare.com/api/v1/files/"${LINE}"/$j/1000?access_token=72d736d5f35d018985315426ea2c65c4&order=size&direction=desc&extensions=xls,xlsx,csv&full-path=1

        echo $RESULTS_DATA >> $APIOUTPUT_FILE
        echo 'download complete'

        if [[ $RESULTS_DATA == *"\"files\":[]}"* ]];
        then
                break
        fi
done

echo $APIOUTPUT_FILE
## Grep out urls and append to urls_to_download.txt
cat $APIOUTPUT_FILE | jq . | grep -a -n 'url' | cut -d '"' -f 4 >> $URLS_TO_DOWNLOAD


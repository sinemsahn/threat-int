mkdir data
mkdir data/pdf_files
mkdir data/text_files
mkdir data/undefined_files

sudo apt update
sudo apt install jq

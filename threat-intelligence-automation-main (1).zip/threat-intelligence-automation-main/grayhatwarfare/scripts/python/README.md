# How2Run
* Run fetch.py
* Run wGetWithMetadata.sh
* Run organize_files.py

* To install dependencies, run install_deps.sh
* wget.py might be discarded, wGetWithMedata.sh seems to do its job really well.


# TODO
* Seperate listing of files and renaming of files in different functions as renaming could be async.
* Add thread support to renaming of files.
* Add parsers for every filetype supported and grep for a list of keywords. (We can start with 3 -> .txt, csv, pdf)
* Add an exiftool module. Grep for relevant things like usernames and discrad the rest.
* Have another file push results to DB, along with timestamp and metadata analysis results.

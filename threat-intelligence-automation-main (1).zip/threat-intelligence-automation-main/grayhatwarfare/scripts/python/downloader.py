import requests
from sys import exit as sys_exit
import subprocess
from sorterscript import *

def construct_args(query_keywords, k, extensions, access_token, is_full_path):
    
    url = f"https://buckets.grayhatwarfare.com/api/v1/files/"
    url += f"{query_keywords}/{k}"
    url += f"/1000?access_token={access_token}"
    url += f"&order=size&direction=desc&extensions={extensions}"
    url += f"&full-path={is_full_path}"

    return url

def run_query(query_keywords, extensions, access_token, is_full_path):

    f = open("urls_to_download.txt", "w+")
    logfile = open("fetch.log", "w+")

    for i in range(1, 50): #Modify these numbers if necessary.
        for k in range(1, 1000): #Do not modify the numbers here.
            k = k * 1000

            url = construct_args(query_keywords, str(k), extensions, access_token, is_full_path)
            r = requests.get(url)
            r = r.json()
            r = r.get("files")

            #Probably redundant unless we are debugging.
            #logfile.write(r.content.decode('utf-8'))
 
            if len(r) == 0:
                    print("Hit end. Querying complete.")
                    break
            tester_counter = 0
            for dictionary in r:
                
                download_url = dictionary.get("url")
                #Threading will need mutex here.
                download_url = download_url.replace(" ", "%20")
                f.write(f"{download_url}\n")
                
                print(download_url + "\n")

                #will trigger with the first saved link, so put it in a for loop if you want
                if tester_counter == 5:
                    
                    break
                tester_counter += 1                
        break
    f.close()

    return 0

def tester():

    rc = subprocess.call(["./automater.sh"])



def initiate(query_keywords):

    #Enter space seperated keywords as you would search in GHW.

    extensions = "csv,xlsx,xls,pdf,txt"
    access_token = "d1fc915b07cb00ac9681c8f9c22987aa" 
    #enable or disable full-path search
    is_full_path = 1

    query_keywords = query_keywords.replace(" ", "%20")
    #Run the code. 
    construct_args(query_keywords, 0, extensions, access_token, is_full_path)
    response = run_query(query_keywords, extensions, access_token, is_full_path)
    #tester()
    
    if response != 0:
        print("Something went wrong. Data might be missing in urls_to_download.txt")
        sys_exit(-1)
    tester()
    start_sort()
    sys_exit(0)

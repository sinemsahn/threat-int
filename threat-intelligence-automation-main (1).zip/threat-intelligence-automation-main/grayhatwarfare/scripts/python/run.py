from downloader import *
keywords_list = ["employee report", "employee meeting"]
for keywords in keywords_list:
    initiate(keywords)
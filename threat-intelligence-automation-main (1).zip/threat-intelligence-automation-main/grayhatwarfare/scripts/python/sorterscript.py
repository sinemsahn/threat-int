from os import chdir, listdir, getcwd, remove, rename, path
import magic
import re

#def grepper_txt():
#    chdir("./text_files")
#    cwd = getcwd() 
#    all_files = listdir(cwd)
#    listowords = ["asd","qwe","zxc"]
#    all_texts = listdir(cwd)
#    for fname in all_files:
#        file = open(fname, "r")
#        for line in file:
#            for pattern in listowords:
#                if re.search(pattern, line):
#                    print(line)

def mainlike():
    cwd = getcwd() 
    all_files = listdir(cwd)
    for fname in all_files:

        fpath = cwd + "/" + fname
        print(fpath)
        print(path.isfile(fpath))
        if not path.isfile(fpath):
            continue

        else:
            print(path.getsize(fpath))
            if path.getsize(fpath) == 0:
                remove(fpath)
                break
            else:
                filetype = magic.from_file(fpath)
                print(type(filetype))
                if "PDF" in filetype:
                    rename(fpath, f"pdf_files/{fname}")

                elif "ASCII" in filetype:
                    rename(fpath, f"text_files/{fname}")
                
                elif "CSV" in filetype:
                    rename(fpath, f"csv_files/{fname}")

                elif "Excel" in filetype:
                    rename(fpath, f"xlsx_files/{fname}")

                #xls and doc
                elif "Composite" in filetype:
                    rename(fpath, f"composite_files/{fname}")
                
                elif "Word" in filetype:
                    rename(fpath, f"docx_files/{fname}")

                elif "PowerPoint" in filetype:
                    rename(fpath, f"pptx_files/{fname}")

                elif "Zip" in filetype:
                    rename(fpath, f"zip_files/{fname}")

                #Will add more types later

                else:
                    rename(fpath, f"undefined_files/{fname}")



def start_sort():
    chdir("./testdata")
    cwd = getcwd() 
    all_files = listdir(cwd)
    mainlike()





#TODO -> Seperate listing of files and renaming of files
#TODO-> Add thread support to renaming of files.

#TODO -> Have another file push results to DB, along with timestamp and metadata analysis results.
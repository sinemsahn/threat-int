import argparse
import requests
import os
import csv
import json
import logging


API_BASE_PATH = "https://buckets.grayhatwarfare.com"
FILES_API_ENDPOINT = "/api/v1/files/"
FILES_API_URL = API_BASE_PATH + FILES_API_ENDPOINT
ACCESS_TOKEN = "d1fc915b07cb00ac9681c8f9c22987aa"


def get_api_results(url, params):
    r = requests.get(url, params=params)
    if r.status_code != 200:
        logging.error(
            "API Response Code: %s, Reason: %s", r.status_code, r.reason
        )
    if "files" not in r.json():
        logging.warning(
            "files was not found in response. url: %s, headers: %s, body: %s",
            r.request.url,
            r.request.headers,
            r.request.body,
        )

    return r.json()


def process_results(files, urls_file):
    with open(urls_file, "a") as f:
        for file in files:
            f.write(json.dumps(file) + "\n")


def parse_query_file(query_file):
    queries = []
    with open(query_file, "r") as f:
        csv_reader = csv.DictReader(f)
        for row in csv_reader:
            queries.append({
                "query": row["Query"],
                "exts": row["File Type"],
            })
    return queries


def download_urls(query_file, urls_file):
    queries = parse_query_file(query_file)

    for query_dict in queries:
        query_params = {
            "access_token": ACCESS_TOKEN,
            "order": "size",
            "direction": "desc",
            "full-path": "1",
            "extensions": query_dict["exts"],
        }
        for i in range(1000):
            query_url = FILES_API_URL \
                + query_dict["query"] + "/" + str(i*1000) + "/1000"
            res = get_api_results(query_url, query_params)
            files = res["files"]

            logging.info("Iteration %d/1000: Got %d results", i, len(files))

            if len(files) == 0:
                break
            process_results(files, urls_file)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Find Gray Hat Warfare results for a query"
    )
    parser.add_argument(
        "-q",
        "--query-file",
        action="store",
        dest="query_file",
        required=True,
        help="Queries csv file path, For example: personal-information.csv",
    )
    parser.add_argument(
        "-o",
        "--output-file",
        action="store",
        dest="urls_file",
        required=True,
        help="GHW Metadata file, For example: ghw_metadata.json",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        dest="verbose",
        help="Show warnings and debug information",
    )
    args = parser.parse_args()
    return args.query_file, args.urls_file, args.verbose


def main(query, urls_file):
    try:
        os.remove(urls_file)
    except FileNotFoundError:
        logging.info("No file to delete: %s does not exist", urls_file)
    download_urls(query, urls_file)


def init_logger():
    logging.basicConfig()
    logging.root.setLevel(logging.NOTSET)


if __name__ == "__main__":
    init_logger()
    _query_file, _urls_file, _verbose = parse_args()

    if not _verbose:
        logging.disable(logging.CRITICAL)
    else:
        logging.disable(logging.DEBUG)

    main(_query_file, _urls_file)

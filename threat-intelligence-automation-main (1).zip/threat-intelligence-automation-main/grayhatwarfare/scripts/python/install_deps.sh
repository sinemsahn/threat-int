sudo apt update
sudo apt install libmagic1
pip3 install -r requirements.txt

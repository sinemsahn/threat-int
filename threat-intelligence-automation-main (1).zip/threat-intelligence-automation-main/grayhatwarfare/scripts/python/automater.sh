#!/bin/bash



filename="urls_to_download.txt"
sed -i 's/ /%20/' $filename

URLS_TO_DOWNLOAD=$1
cat $filename | parallel -j 8 ./wgetWithMetaData.sh


sed -i "1ifilename,url_source,datetime,hash,filesize_bytes" meta_output.csv



grep -A 1 -B 1 " failed: " log.txt > failedLog.txt

cat failedLog.txt | tr ' ' '\n' | grep 'http' > failedUrls.txt


find ./testdata -type f -size 0 -delete

##downloaded all of them

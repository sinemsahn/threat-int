from multiprocessing import Process
import logging
import argparse
import os

from google.scripts import download_urls as google_urls
from grayhatwarfare.scripts.python import download_urls as ghw_urls
from utils import download_files


GOOGLE_URLS_FILE = "google_urls.txt"
GHW_URLS_FILE = "ghw_urls.txt"


def run_google_queries_and_download(
    company_name,
    domain_name,
    urls_file,
    out_dir
):
    google_urls.main(company_name, domain_name, urls_file)
    download_files.main(urls_file, out_dir)


def run_ghw_queries_and_download(ghw_query, urls_file, out_dir):
    ghw_urls.main(ghw_query, urls_file)
    download_files.main(urls_file, out_dir)


def main(google_company_name, google_domain_name, ghw_query, out_dir):
    google_args_present = (
        google_company_name is not None
    ) and (
        google_domain_name is not None
    )

    ghw_args_present = ghw_query is not None

    google_p = Process(
        target=run_google_queries_and_download,
        args=(
            google_company_name,
            google_domain_name,
            GOOGLE_URLS_FILE,
            out_dir,
        )
    )

    ghw_p = Process(
        target=run_ghw_queries_and_download,
        args=(
            ghw_query,
            GHW_URLS_FILE,
            out_dir,
        )
    )

    if google_args_present:
        google_p.start()
    if ghw_args_present:
        ghw_p.start()

    if google_args_present:
        google_p.join()
    if ghw_args_present:
        ghw_p.join()

    if os.path.exists(GOOGLE_URLS_FILE):
        os.remove(GOOGLE_URLS_FILE)
    if os.path.exists(GHW_URLS_FILE):
        os.remove(GHW_URLS_FILE)


def parse_args():
    parser = argparse.ArgumentParser(
        description="""Run Google and gwh queries and download.
        Either Google query args or GHW query args are required"""
    )
    parser.add_argument(
        "-c",
        "--google-company-name",
        action="store",
        dest="google_company_name",
        required=False,
        help="Company Name, For example: Google",
    )
    parser.add_argument(
        "-d",
        "--google-domain-name",
        action="store",
        dest="google_domain_name",
        required=False,
        help="Domain Name, For example: google (without com)",
    )
    parser.add_argument(
        "-q",
        "--ghw-query",
        action="store",
        dest="ghw_query",
        required=False,
        nargs="*",
        help="Query, For example: employee report",
    )
    parser.add_argument(
        "-o",
        "--out-dir",
        action="store",
        dest="out_dir",
        required=True,
        help="Output directory, For example: data",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        dest="verbose",
        help="Show warnings and debug information",
    )
    args = parser.parse_args()
    google_args_present = (
        args.google_company_name is not None
    ) and (
        args.google_domain_name is not None
    )

    ghw_args_present = args.ghw_query is not None

    if not google_args_present and not ghw_args_present:
        parser.print_help()
        parser.exit()

    if ghw_args_present:
        args.ghw_query = "%20".join(args.ghw_query)

    return (
        args.google_company_name,
        args.google_domain_name,
        args.ghw_query,
        args.out_dir,
        args.verbose
    )


def init_logger():
    logging.basicConfig()
    logging.root.setLevel(logging.NOTSET)


if __name__ == "__main__":
    init_logger()
    _google_company, _google_domain, _ghw_query, _out_dir, _verbose = parse_args()

    if not _verbose:
        logging.disable(logging.CRITICAL)
    else:
        logging.disable(logging.DEBUG)

    main(_google_company, _google_domain, _ghw_query, _out_dir)
